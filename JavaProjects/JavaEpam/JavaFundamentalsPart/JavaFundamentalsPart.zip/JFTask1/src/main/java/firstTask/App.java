package firstTask;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Scanner in = new Scanner(System.in);
        String name = in.nextLine();
        System.out.println("Hello, " +  name + "!");
    }
}
