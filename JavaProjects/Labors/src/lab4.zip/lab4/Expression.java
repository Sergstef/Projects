package lab4;
public class Expression {

	public static void main(String[] args) {
			String str = "5+10+25+35"; 
			String fr[] = str.split("[+]"); 
			int a = Integer.parseInt(fr[0]); 
			int b = Integer.parseInt(fr[1]); 
			int c = Integer.parseInt(fr[2]); 
			int d = Integer.parseInt(fr[3]); 
			int result = a+b+c+d; 
			System.out.println(result); 
	}

}
