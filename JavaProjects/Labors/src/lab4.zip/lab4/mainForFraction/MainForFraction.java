package lab4.mainForFraction;

import lab6.fraction.Fraction;

public class MainForFraction {

	public static void main(String[] args) {
		Fraction[] ar = new Fraction[5];

		Fraction fig1 = new Fraction();
		Fraction fig2 = new Fraction(1, 2);
		ar[0] = fig2;
		Fraction fig3 = new Fraction(1, 2);
		ar[1] = fig3;
		Fraction fig4 = new Fraction(1);
		ar[2] = fig4;
		Fraction fig5 = new Fraction();
		Fraction fig6 = new Fraction();
		Fraction fig7 = new Fraction();

		Fraction fig11 = new Fraction(2);
		ar[3] = fig11;
		Fraction fig22 = new Fraction(3);
		ar[4] = fig22;

		for (int i = 0; i < ar.length; i++) {
			ar[i].reduction();
			ar[i].prt();
		}
		System.out.println();

		System.out.println("add");
		fig5.add(ar);
		fig5.prt();
		fig5.reduction();
		fig5.prt();
		System.out.println();

		System.out.println("multiplication");
		fig6.multiplication(ar);
		fig6.prt();
		fig6.reduction();
		fig6.prt();
		System.out.println();

		System.out.println("division");
		fig7.division(ar);
		fig7.prt();
		fig7.reduction();
		fig7.prt();
		System.out.println();


	}

}
