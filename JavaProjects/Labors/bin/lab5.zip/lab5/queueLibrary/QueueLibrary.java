package lab5.queueLibrary;

import java.util.LinkedList;
import java.util.Queue;

public class QueueLibrary {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList();
        queue.add(1546);
        queue.add(234);
        queue.add(345);
        queue.add(2354234);
        queue.add(823);
        queue.add(234);
        queue.add(456);
        queue.add(23425);
        queue.add(56546);


        System.out.println("Peek");
        System.out.println(queue.peek());
        System.out.println();
        System.out.println("Size");
        System.out.println(queue.size());
        System.out.println();
        System.out.println("Add 12");
        System.out.println(queue.add(12));
        System.out.println();
        System.out.println("Poll");
        System.out.println(queue.poll());
        System.out.println();
        System.out.println("Poll");
        System.out.println(queue.poll());
        System.out.println();
        System.out.println("Size");
        System.out.println(queue.size());
        
    }



}
