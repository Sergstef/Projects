package lab5.myQueue;

import java.util.Arrays;

public class MyQueue {
    private int[] queue;
    private int maxSize;
    private int elementsInQueue;
    private int front; 
    private int rear; 
    

    @Override
	public String toString() {
		return "MyQueue [queue=" + Arrays.toString(queue) + ", maxSize=" + maxSize + ", elementsInQueue="
				+ elementsInQueue + ", front=" + front + ", rear=" + rear + "]";
	}

	public MyQueue(int maxSize) {
        this.maxSize = maxSize;
        queue = new int[maxSize];
        rear = -1;
        front = 0;
        elementsInQueue = 0;
    }

    public void insert(int elem) {
        if (rear == maxSize - 1) {
        	maxSize = maxSize + 5;
            int [] qrqer = new int[maxSize];
            for(int i =0; i < queue.length; i++) {
            	qrqer[i] = queue[i];
            }
            this.queue = qrqer;
        }
        queue[++rear] = elem;
        elementsInQueue++;
    }

    public int remove() {
        int temp = queue[front++];

        if (front == maxSize) {
            front = 0;
        }
        elementsInQueue--;
        return temp;
    }
    public int getFront() {
        return queue[front];
    }

    public int getRear() {
        return queue[rear];
    }

    public boolean isFull() {
        return (elementsInQueue == maxSize - 1);
    }

    public boolean isEmpty() {
        return (elementsInQueue == 0);
    }

    public int getSize() {
        return elementsInQueue;
    }

    public static void main(String[] args) {
        MyQueue myQueue = new MyQueue(5);

        myQueue.insert(10);
        myQueue.insert(20);
        myQueue.insert(30);
        myQueue.insert(40);
        myQueue.insert(50);
        myQueue.insert(60);
        myQueue.insert(70);
        myQueue.insert(80);
        myQueue.insert(90);
        myQueue.insert(100);
        myQueue.insert(110);
        System.out.println(myQueue.remove()); 


        while (!myQueue.isEmpty()) {
            int n = myQueue.remove();
            System.out.println("Elem: " + n);
        }

    }
}
