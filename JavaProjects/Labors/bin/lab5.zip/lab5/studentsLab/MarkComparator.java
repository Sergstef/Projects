package lab5.studentsLab;

import java.util.Comparator;

public class MarkComparator implements Comparator<Student> {
    public int compare(Student student, Student t1) {
        if (student.getMark() > t1.getMark()){
            return 1;
        } else if(student.getMark() < t1.getMark()){
            return -1;
        } else return 0;
    }
}
