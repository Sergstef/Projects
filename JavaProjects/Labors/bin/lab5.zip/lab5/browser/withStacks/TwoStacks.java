package lab5.browser.withStacks;

import java.util.Arrays;

public class TwoStacks {
	private int [] firstBrowser = {1,2,3,4,5};
	private int indexOpen = 5;
	private int [] secondBrowser = {0,0,0,0,0};
	private int indexClose = 0;
	@Override
	public String toString() {
		return "TwoStacks [firstBrowser=" + Arrays.toString(firstBrowser) + ", indexOpen=" + indexOpen
				+ ", secondBrowser=" + Arrays.toString(secondBrowser) + ", indexClose=" + indexClose + "]";
	}
	public void openThePage() {
		indexOpen--;
		if(indexOpen >= 0 & indexOpen <= 4) {
		secondBrowser[indexClose] = firstBrowser[indexOpen];
		firstBrowser[indexOpen] = 0;
		System.out.println("Current page is " + secondBrowser[indexClose] );
		indexClose++;
		}
		else {
			System.out.println("There is no page to open");
		}
		
	}
	public void closeThePage() {
		indexClose--;
		indexOpen++;
		if(indexClose >= 0 & indexClose <= 4) {
			firstBrowser[indexOpen] = secondBrowser[indexClose];
			
			secondBrowser[indexClose] = 0;
			if(indexClose >= 1 & indexClose <= 4) {
				System.out.println("Current page is " + secondBrowser[indexClose -1] );
			}
			}
			else {
				System.out.println("There is no page to close");
			}
	}

}
