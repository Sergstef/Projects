package lab5.browser.withStacks;



public class Main {

	public static void main(String[] args) {
		TwoStacks browser = new TwoStacks();
		System.out.println(browser.toString());
		browser.openThePage();
		System.out.println(browser.toString());
		browser.openThePage();
		System.out.println(browser.toString());
		browser.openThePage();
		System.out.println(browser.toString());
		browser.openThePage();
		System.out.println(browser.toString());
		browser.openThePage();
		System.out.println(browser.toString());
		browser.openThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
		browser.closeThePage();
		System.out.println(browser.toString());
	}

}
