package lab5.browser.withArray;

import java.util.Arrays;

public class Stack {
	private int browser [] = {1,2,3,4,5};
	private int index = -1;
	@Override
	public String toString() {
		return "Stack [browser=" + Arrays.toString(browser) + ", index=" + index + "]";
	}
	public void goForward() {
		this.index++;
		if(this.index > this.browser.length - 1 | this.index < 0) {
			System.out.println("The page is empty");
		}
		else {
		System.out.println(Arrays.toString(browser));
		System.out.println("Current page is " + this.browser[this.index]);
		}
	} 
	public void goBack() {
		this.index--;
		if(this.index < 0 | this.index > this.browser.length - 1) {
			System.out.println("The page is empty");
		}
		else {
		System.out.println(Arrays.toString(browser));
		System.out.println("Current page is " + this.browser[this.index]);
		}
		
	}

}
