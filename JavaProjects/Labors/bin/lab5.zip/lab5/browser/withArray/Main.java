package lab5.browser.withArray;

public class Main {

	public static void main(String[] args) {
		Stack browser = new Stack();
		browser.goForward();
		
		browser.goForward();
		browser.goForward();
		browser.goForward();
		browser.goForward();
		browser.goForward();
		browser.goForward();
		browser.goBack();
		browser.goBack();
		browser.goBack();

	}

}
