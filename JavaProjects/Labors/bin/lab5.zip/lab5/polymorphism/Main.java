package lab5.polymorphism;
import lab5.polymorphism.animals.kindsOfAnimals.*;
import lab5.polymorphism.animals.*;
public class Main {

	public static void main(String[] args) {
		Animal tiger = new Tiger();
		Animal cat = new Cat();
		Animal cat2 = new Animal();
		tiger.say();
		cat.say();
		cat2.say();

	}

}
