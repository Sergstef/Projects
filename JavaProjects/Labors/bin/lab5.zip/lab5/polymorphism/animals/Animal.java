package lab5.polymorphism.animals;

public class Animal {
	public Animal() {
		
	}
	public void say () {
		System.out.println("Yaaaa");
	}

}
