package lab5.polymorphism.animals.kindsOfAnimals;


import lab5.polymorphism.animals.Animal;

public class Cat extends Animal {
	@Override
	public void say() {
		System.out.println("Myauuuu");
	}

}
