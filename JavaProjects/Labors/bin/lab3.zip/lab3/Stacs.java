package lab3;

import java.util.Random;

public class Stack {
	int length;
	int tos;
	int pushId;
	int popId;
	int number;
	int[] stack;
	int[] pushes;
	int[] pops;

	Stack() {
		Random rand = new Random();
		length = 5;
		tos = -1;
		number = rand.nextInt(10) + 1;
		stack = new int[length];
		pushes = new int[number];
		pops = new int[number];
		for (int i = 0; i < stack.length; i++)
			stack[i] = 0;

		for (int i = 0; i < number; i++) {
			pushes[i] = 0;
			pops[i] = 0;
		}
	}

	Stack(int len, int numb) {
		length = len;
		tos = -1;
		number = numb;
		stack = new int[length];
		pushes = new int[number];
		pops = new int[number];
		for (int i = 0; i < stack.length; i++)
			stack[i] = 0;
		for (int i = 0; i < number; i++) {
			pushes[i] = 0;
			pops[i] = 0;
		}

	}

	void push() {
		Random rand = new Random();
		int qwerty = rand.nextInt(20) + 1;
		stack[++tos] = qwerty;
		pushes[pushId++] = qwerty;
	}

	void pop() {
		pops[popId++] = stack[tos];
		stack[tos--] = 0;
	}

}


