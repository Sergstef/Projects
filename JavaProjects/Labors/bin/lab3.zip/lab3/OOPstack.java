package lab3;

import java.util.*;

class Stack {
	int length;
	int tos;
	int pushId;
	int popId;
	int number;
	int[] stack;
	int[] pushes;
	int[] pops;

	Stack() {
		Random rand = new Random();
		length = 5;
		tos = -1;
		number = rand.nextInt(10) + 1;
		stack = new int[length];
		pushes = new int[number];
		pops = new int[number];
		for (int i = 0; i < stack.length; i++)
			stack[i] = 0;

		for (int i = 0; i < number; i++) {
			pushes[i] = 0;
			pops[i] = 0;
		}
	}

	void push() {
		Random rand = new Random();
		int qwerty = rand.nextInt(20) + 1;
		stack[++tos] = qwerty;
		pushes[pushId++] = qwerty;
	}

	void pop() {
		pops[popId++] = stack[tos];
		stack[tos--] = 0;
	}

}

public class OOPstack {
	public static void main(String[] args) {
		Random rand = new Random();
		Stack stack1 = new Stack();
		System.out.println("number of iterrations = " + stack1.number);
		System.out.println();

		for (int i = 0; i < stack1.number; i++) {
			for (int k = 0; k < stack1.length; k++)
				System.out.print(stack1.stack[k] + " ");
			System.out.println();
			int num = rand.nextInt(2);
			System.out.print("num = " + num);
			if (num == 0)
				System.out.println(" (push)");
			else
				System.out.println(" (pop)");

			if (num == 0) {
				if (stack1.tos < stack1.length - 1) {
					stack1.push();
					System.out.println(stack1.pushes[stack1.pushId - 1]);
					System.out.println();
				} else {
					System.out.println("Error: stack is overfilled");
					System.out.println();
				}
			}

			if (num == 1) {
				if (stack1.tos >= 0) {
					stack1.pop();
					System.out.println(stack1.pops[stack1.popId - 1]);
					System.out.println();
				} else {
					System.out.println("Error: stack isn't filled");
					System.out.println();
				}
			}
		}

		System.out.println();
		for (int i = 0; i < stack1.length; i++)
			System.out.print(stack1.stack[i] + " ");
		System.out.println();

		System.out.print("Pushes: ");
		for (int i = 0; i < stack1.number; i++)
			if (stack1.pushes[i] != 0)
				System.out.print(stack1.pushes[i] + " ");
			else
				break;
		System.out.println();

		System.out.print("Pops: ");
		for (int i = 0; i < stack1.number; i++)
			if (stack1.pops[i] != 0)
				System.out.print(stack1.pops[i] + " ");
			else
				break;
		System.out.println();
	}

}
